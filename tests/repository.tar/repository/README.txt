sample git repository to be used by testcases
